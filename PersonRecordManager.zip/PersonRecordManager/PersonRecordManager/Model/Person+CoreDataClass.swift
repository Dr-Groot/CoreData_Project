//
//  Person+CoreDataClass.swift
//  PersonRecordManager
//
//  Created by Amam Pratap Singh on 20/02/23.
//
//

import Foundation
import CoreData

@objc(Person)
public class Person: NSManagedObject {

}
